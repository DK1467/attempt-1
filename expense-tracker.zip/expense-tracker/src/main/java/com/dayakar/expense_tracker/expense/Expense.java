package com.dayakar.expense_tracker.expense;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
public class Expense {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank
	@Size(max = 200)
	private String description;

	@NotNull
	@DecimalMin("0.01")
	@Column(precision = 12, scale = 2)
	private BigDecimal amount;

	@NotNull
	private LocalDate date;

	@NotBlank
	@Size(max = 50)
	private String category;

	protected Expense() {
	}

	public Expense(String description, BigDecimal amount, LocalDate date, String category) {
		this.description = description;
		this.amount = amount;
		this.date = date;
		this.category = category;
	}

	public Long getId() { return id; }
	public String getDescription() { return description; }
	public void setDescription(String description) { this.description = description; }
	public BigDecimal getAmount() { return amount; }
	public void setAmount(BigDecimal amount) { this.amount = amount; }
	public LocalDate getDate() { return date; }
	public void setDate(LocalDate date) { this.date = date; }
	public String getCategory() { return category; }
	public void setCategory(String category) { this.category = category; }
}
