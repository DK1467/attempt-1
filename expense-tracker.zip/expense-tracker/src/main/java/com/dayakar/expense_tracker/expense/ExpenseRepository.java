package com.dayakar.expense_tracker.expense;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {

	List<Expense> findByCategoryOrderByDateDesc(String category);

	List<Expense> findByDateBetweenOrderByDateAsc(LocalDate from, LocalDate to);
}
