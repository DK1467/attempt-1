package com.dayakar.expense_tracker.expense;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

	private final ExpenseRepository repository;

	public ExpenseController(ExpenseRepository repository) {
		this.repository = repository;
	}

	@GetMapping
	public List<Expense> list(@RequestParam(required = false) String category) {
		if (category != null) {
			return repository.findByCategoryOrderByDateDesc(category);
		}
		return repository.findAll();
	}

	@GetMapping("/{id}")
	public Expense get(@PathVariable Long id) {
		return repository.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
	}

	@PostMapping
	public ResponseEntity<Expense> create(@Valid @RequestBody Expense expense) {
		Expense saved = repository.save(expense);
		return ResponseEntity.created(URI.create("/api/expenses/" + saved.getId())).body(saved);
	}

	@PutMapping("/{id}")
	public Expense update(@PathVariable Long id, @Valid @RequestBody Expense update) {
		Expense existing = get(id);
		existing.setDescription(update.getDescription());
		existing.setAmount(update.getAmount());
		existing.setDate(update.getDate());
		existing.setCategory(update.getCategory());
		return repository.save(existing);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id) {
		if (!repository.existsById(id)) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
		repository.deleteById(id);
	}
}
