package com.dayakar.expense_tracker.expense;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ExpenseControllerTests {

	private static final String VALID = """
			{"description":"Coffee","amount":4.50,"date":"2026-03-10","category":"food"}""";

	@Autowired
	MockMvc mvc;

	@Test
	void createReturns201WithLocation() throws Exception {
		mvc.perform(post("/api/expenses").contentType(MediaType.APPLICATION_JSON).content(VALID))
				.andExpect(status().isCreated())
				.andExpect(header().string("Location", containsString("/api/expenses/")))
				.andExpect(jsonPath("$.description").value("Coffee"));
	}

	@Test
	void createRejectsNonPositiveAmount() throws Exception {
		String bad = VALID.replace("4.50", "0");
		mvc.perform(post("/api/expenses").contentType(MediaType.APPLICATION_JSON).content(bad))
				.andExpect(status().isBadRequest());
	}

	@Test
	void getUnknownIdReturns404() throws Exception {
		mvc.perform(get("/api/expenses/999999")).andExpect(status().isNotFound());
	}

	@Test
	void deleteRemovesExpense() throws Exception {
		String location = mvc.perform(post("/api/expenses").contentType(MediaType.APPLICATION_JSON).content(VALID))
				.andReturn().getResponse().getHeader("Location");
		mvc.perform(delete(location)).andExpect(status().isNoContent());
		mvc.perform(get(location)).andExpect(status().isNotFound());
	}
}
