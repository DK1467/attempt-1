package com.dayakar.expense_tracker.expense;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class ExpenseRepositoryTests {

	@Autowired
	ExpenseRepository repository;

	@Test
	void findsByCategoryNewestFirst() {
		repository.save(new Expense("Lunch", new BigDecimal("12.50"), LocalDate.of(2026, 3, 1), "food"));
		repository.save(new Expense("Dinner", new BigDecimal("30.00"), LocalDate.of(2026, 3, 5), "food"));
		repository.save(new Expense("Bus", new BigDecimal("2.75"), LocalDate.of(2026, 3, 2), "transport"));

		List<Expense> food = repository.findByCategoryOrderByDateDesc("food");

		assertThat(food).extracting(Expense::getDescription).containsExactly("Dinner", "Lunch");
	}

	@Test
	void findsByDateRangeInclusive() {
		repository.save(new Expense("A", new BigDecimal("1.00"), LocalDate.of(2026, 3, 1), "x"));
		repository.save(new Expense("B", new BigDecimal("1.00"), LocalDate.of(2026, 3, 31), "x"));
		repository.save(new Expense("C", new BigDecimal("1.00"), LocalDate.of(2026, 4, 1), "x"));

		List<Expense> march = repository.findByDateBetweenOrderByDateAsc(
				LocalDate.of(2026, 3, 1), LocalDate.of(2026, 3, 31));

		assertThat(march).extracting(Expense::getDescription).containsExactly("A", "B");
	}
}
